#!/bin/bash

mkdir -p /luna
if which mkfs.ext4 > /dev/null ;then
    if ls /dev/xvdb1 &> /dev/null;then
       if cat /etc/fstab|grep /luna > /dev/null ;then
            if cat /etc/fstab|grep /luna|grep ext3 > /dev/null ;then
                sed -i "/\/luna/d" /etc/fstab
            fi
       else
            echo '/dev/xvdb1             /luna                 ext4    defaults        0 0' >> /etc/fstab
       fi
       mount -a
    fi
else
    if ls /dev/xvdb1 &> /dev/null;then
       if cat /etc/fstab|grep /luna > /dev/null ;then
            echo ""
       else
            echo '/dev/xvdb1             /luna                 ext3    defaults        0 0' >> /etc/fstab
       fi
       mount -a
    fi
fi

rm -rf /usr/local/freetype.2.1.10
rm -rf /usr/local/libpng.1.2.50
rm -rf /usr/local/freetype.2.1.10
rm -rf /usr/local/libpng.1.2.50
rm -rf /usr/local/jpeg.6

./nginx/uninstall.sh
