#!/bin/bash

echo 'uninstall mysql'

userdel mysql
/etc/init.d/mysqld stop &> /dev/null
killall mysqld &> /dev/null
rm -rf /luna/mysql
rm -f /etc/my.cnf
rm -f /etc/init.d/mysqld

if [ -L /etc/rc.local ];then
	echo ""
else
	rm -rf /etc/rc.local
	ln -s /etc/rc.d/rc.local /etc/rc.local
fi
sed -i "/\/etc\/init\.d\/mysqld.*/d" /etc/rc.d/rc.local
sed -i "/export PATH=\$PATH\:\/luna\/mysql\/bin.*/d" /etc/profile
source /etc/profile
