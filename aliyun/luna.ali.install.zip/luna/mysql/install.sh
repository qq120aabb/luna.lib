#!/bin/bash

cd /luna-install/luna/mysql
mkdir -p /luna/mysql
mkdir -p /luna/log/mysql

rm -rf mysql-5.6.15-linux-glibc2.5-x86_64
if [ ! -f mysql-5.6.15-linux-glibc2.5-x86_64.tar.gz ];then
	wget http://oss.aliyuncs.com/aliyunecs/onekey/mysql/mysql-5.6.15-linux-glibc2.5-x86_64.tar.gz
fi
tar -xzvf mysql-5.6.15-linux-glibc2.5-x86_64.tar.gz
mv mysql-5.6.15-linux-glibc2.5-x86_64/* /luna/mysql

groupadd mysql
useradd -g mysql -s /sbin/nologin mysql
/luna/mysql/scripts/mysql_install_db --datadir=/luna/mysql/data/ --basedir=/luna/mysql --user=mysql
chown -R mysql:mysql /luna/mysql/
chown -R mysql:mysql /luna/mysql/data/
chown -R mysql:mysql /luna/log/mysql
cp -f /luna/mysql/support-files/mysql.server /etc/init.d/mysqld
cp -f my.cnf /etc/my.cnf
sed -i 's#^basedir=$#basedir=/luna/mysql#' /etc/init.d/mysqld
sed -i 's#^datadir=$#datadir=/luna/mysql/data#' /etc/init.d/mysqld

if ! cat /etc/rc.local | grep "/etc/init.d/mysqld" > /dev/null;then 
    echo "/etc/init.d/mysqld start" >> /etc/rc.local
fi

echo 'export PATH=$PATH:/luna/mysql/bin' >> /etc/profile
source /etc/profile

chmod 755 /etc/init.d/mysqld
/etc/init.d/mysqld start
