#!/bin/bash

####---- install dependencies ----begin####
sed -i 's/^exclude/#exclude/' /etc/yum.conf
yum makecache
yum -y remove mysql MySQL-python perl-DBD-MySQL dovecot exim qt-MySQL perl-DBD-MySQL dovecot qt-MySQL mysql-server mysql-connector-odbc php-mysql mysql-bench libdbi-dbd-mysql mysql-devel-5.0.77-3.el5 httpd php mod_auth_mysql mailman squirrelmail php-pdo php-common php-mbstring php-cli &> /dev/null
yum -y install gcc gcc-c++ gcc-g77 make libtool autoconf patch unzip automake libxml2 libxml2-devel ncurses ncurses-devel libtool-ltdl-devel libtool-ltdl libmcrypt libmcrypt-devel libpng libpng-devel libjpeg-devel openssl openssl-devel curl curl-devel libxml2 libxml2-devel ncurses ncurses-devel libtool-ltdl-devel libtool-ltdl autoconf automake libaio*
iptables -F

####---- install software ----begin####
./env/install_set_sysctl.sh
./env/install_set_ulimit.sh

if [ -e /dev/xvdb ];then
    ./env/install_disk.sh
fi

./env/install_dir.sh
./env/install_env.sh

./jdk/install.sh
./nginx/install.sh
./mysql/install.sh
./tomcat/install.sh



