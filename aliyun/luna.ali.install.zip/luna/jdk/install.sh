#!/bin/bash

cd /luna-install/luna/jdk
mkdir -p /luna/jdk
cp -f jdk-6u31-linux-x64.bin /luna/jdk
chmod 700 /luna/jdk/jdk-6u31-linux-x64.bin
cd /luna/jdk
./jdk-6u31-linux-x64.bin
rm -f jdk-6u31-linux-x64.bin
