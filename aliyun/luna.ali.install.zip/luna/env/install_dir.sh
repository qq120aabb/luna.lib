#!/bin/bash

userdel www
groupadd www
useradd -g www -M -d /luna/www -s /bin/bash www &> /dev/null
usermod -L www

mkdir -p /luna
mkdir -p /luna/www
mkdir -p /luna/app
mkdir -p /luna/log/nginx
mkdir -p /luna/log/mysql
mkdir -p /luna/log/tomcat
chown -R www:www /luna/log
chown -R www:www /luna/app
chmod -R 700 /luna/log
chmod -R 700 /luna/app

