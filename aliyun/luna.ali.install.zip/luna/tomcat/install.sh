#!/bin/bash

cd /luna-install/luna/tomcat

tar -xzvf apache-tomcat-7.0.37.tar.gz
cp -R apache-tomcat-7.0.37 /luna/tomcat
ln -s /luna/tomcat/bin/shutdown.sh /luna/tomcat/bin/stop_tomcat
cat > /luna/tomcat/bin/start_tomcat <<END
#!/bin/bash
JAVA_HOME=/luna/jdk/jdk1.6.0_31
export JAVA_HOME
su -c /luna/tomcat/bin/startup.sh www
END
chown -R www:www /luna/tomcat
chmod +x /luna/tomcat/bin/start_tomcat

echo 'export PATH=$PATH:/luna/tomcat/bin' >> /etc/profile
source /etc/profile

if ! cat /etc/rc.local | grep "/luna/tomcat/bin/start_tomcat" > /dev/null;then
    echo "/luna/tomcat/bin/start_tomcat" >> /etc/rc.local
fi

/luna/tomcat/bin/start_tomcat
