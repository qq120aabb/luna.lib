#!/bin/bash

JAVA_HOME=/luna/jdk/jdk1.6.0_31
export JAVA_HOME
/luna/tomcat/bin/stop_tomcat
rm -rf /luna/tomcat

sed -i "/\/luna\/tomcat\/bin\/start_tomcat.*/d" /etc/rc.d/rc.local
sed -i "/export PATH=\$PATH\:\/luna\/tomcat\/bin.*/d" /etc/profile
source /etc/profile
