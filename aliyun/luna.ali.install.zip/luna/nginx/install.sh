#!/bin/bash

cd /luna-install/luna/nginx

rm -rf nginx-1.4.4
if [ ! -f nginx-1.4.4.tar.gz ];then
  wget http://oss.aliyuncs.com/aliyunecs/onekey/nginx/nginx-1.4.4.tar.gz
fi
tar zxvf nginx-1.4.4.tar.gz
cd nginx-1.4.4
./configure --user=www \
--group=www \
--prefix=/luna/nginx \
--with-http_stub_status_module \
--without-http-cache \
--with-http_ssl_module \
--with-http_gzip_static_module
CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install

cd ..
cp -f nginx.conf /luna/nginx/conf/
cp -f app.conf /luna/nginx/conf/
sed -i 's/worker_processes  2/worker_processes  '"$CPU_NUM"'/' /luna/nginx/conf/nginx.conf
chmod 755 /luna/nginx/sbin/nginx

cp -f nginx /etc/init.d/
chmod +x /etc/init.d/nginx
if ! cat /etc/rc.local | grep "/etc/init.d/nginx" > /dev/null;then 
	echo "/etc/init.d/nginx start" >> /etc/rc.local
fi

/etc/init.d/nginx start
