#!/bin/bash

/etc/init.d/nginx stop &> /dev/null
killall nginx &> /dev/null

sed -i "/\/etc\/init\.d\/nginx.*/d" /etc/rc.d/rc.local
rm -rf /luna/nginx
rm -f /etc/init.d/nginx
